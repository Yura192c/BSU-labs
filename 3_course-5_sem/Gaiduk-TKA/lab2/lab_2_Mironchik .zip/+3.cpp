#include <iostream>
#include <fstream>

using namespace std;

int main() {
    fstream fin;
    fin.open("input.txt");
    int s = 1, num = 0;
    int a;
    char mas[40];
    while (fin >> a) {
        cout << a;
        switch (s) {
            case 1: {
                switch (a) {
                    case 0: {

                        mas[num] = '1';
                        s = 5;
                        break;
                    }
                    case 1: {
                        mas[num] = '0';
                        s = 2;
                        break;
                    }
                }
                break;

            }
            case 2: {
                switch (a) {
                    case 0: {
                        mas[num] = '0';
                        s = 5;
                        break;
                    }
                    case 1: {
                        mas[num] = '1';
                        s = 3;
                        break;
                    }
                }
                break;
            }
            case 3: {
                switch (a) {
                    case 0: {
                        mas[num] = '1';
                        s = 4;
                        break;
                    }
                    case 1: {
                        mas[num] = '0';
                        s = 3;
                        break;
                    }

                }
                break;
            }
            case 4: {
                switch (a) {
                    case 0: {
                        mas[num] = '0';
                        s = 4;
                        break;
                    }
                    case 1: {
                        mas[num] = '1';
                        s = 4;
                        break;
                    }

                }
                break;
            }
            case 5: {
                switch (a) {
                    case 0: {
                        mas[num] = '1';
                        s = 4;
                        break;
                    }
                    case 1: {
                        mas[num] = '0';
                        s = 3;
                        break;
                    }

                }
                break;
            }

        }
        num++;
    }
    int q = 0;
    cout << num;
    for (int i = 0; i < num; i++) {
        cout << mas[i];
    }

}