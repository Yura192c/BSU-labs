#include <iostream>
#include <fstream>

using namespace std;

int main() {
    fstream fin("input.txt");
    ofstream fout("output.txt");
    int s = 1, num = 0;
    int a;
    char mas[40];
    while (fin >> a) {
        switch (s) {
            case 1: {
                switch (a) {
                    case 0: {

                        mas[num] = '1';
                        s = 2;
                        break;;
                    }
                    case 1: {
                        mas[num] = '0';
                        s = 1;
                        break;
                    }
                }
                break;

            }
            case 2: {
                switch (a) {
                    case 0: {
                        mas[num] = '0';
                        s = 2;
                        break;
                    }
                    case 1: {
                        mas[num] = '1';
                        s = 2;
                        break;
                    }
                }
                break;
            }


        }
        num++;
    }
    int q = 0;
    for (int i = 0; i < num; i++) {
        cout << mas[i];
    }
    fout << endl;
    fout << q;

}